# Site du Mini FAPO 2026

Site officiel du **Festival des Arts de la Polynésie Occidentale** (Mini FAPO),
du 6 au 11 décembre 2026 à Sausau, Nuku, Futuna.

## Contenu du dossier

- `index.html` : la page du site (tous les textes sont ici)
- `css/style.css` : les couleurs, polices et la mise en page
- `js/script.js` : le menu sur téléphone et le compte à rebours
- `images/` : les photos et logos du festival

## Mettre à jour le site

Dans `index.html`, cherche `À METTRE À JOUR` (Ctrl + F) pour trouver
toutes les zones à compléter. Quand tout est à jour, supprime
`class="mode-brouillon"` sur la balise `<body>`.
