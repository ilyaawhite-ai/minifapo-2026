// Mini FAPO 2026 – petits comportements du site

// 1. Menu sur téléphone : ouvrir / fermer
const bouton = document.querySelector(".menu-bouton");
const menu = document.getElementById("menu");

bouton.addEventListener("click", () => {
  const ouvert = menu.classList.toggle("ouvert");
  bouton.setAttribute("aria-expanded", ouvert);
});

// Refermer le menu quand on clique sur un lien
menu.querySelectorAll("a").forEach((lien) => {
  lien.addEventListener("click", () => {
    menu.classList.remove("ouvert");
    bouton.setAttribute("aria-expanded", false);
  });
});

// 2. Compte à rebours jusqu'à l'ouverture
// (si les dates changent, modifie les dates ci-dessous)
const ouverture = new Date("2026-12-06T00:00:00+12:00"); // heure de Futuna
const fin = new Date("2026-12-12T00:00:00+12:00");
const compteur = document.getElementById("compteur");

const maintenant = new Date();
const jours = Math.ceil((ouverture - maintenant) / (1000 * 60 * 60 * 24));

if (maintenant < ouverture) {
  compteur.textContent = jours > 1 ? `Plus que ${jours} jours avant l'ouverture` : "Ouverture demain !";
} else if (maintenant < fin) {
  compteur.textContent = "Le festival a lieu en ce moment !";
} else {
  compteur.textContent = "Merci à toutes et à tous, à bientôt !";
}
